# Demo image notes

## Product photos

The catalogue now has **200 real local stock-photo files for 200 products** under `public/products/catalog/`. Each SKU points to one separate WebP photo. `data/product_photos.json` records the product ID, local path, source group, imported filename and content hash; the smoke test checks that all 200 files exist and no content hash is reused.

The product photos are Pexels stock photographs, selected to match the broad clothing/footwear category. They are **not verified photos of the exact mock product, brand, model or colour**. The catalogue data is still mock data, so the product detail view labels the image as a reference photo. Do not present these as the exact item for sale or imply that pictured people/brands endorse VastraVibe. For an actual store, replace the reference photos with exact variant photos supplied by the seller or another authorized product feed, and keep source/license and model/property-release records.

Review the current [Pexels license](https://www.pexels.com/license/) before deployment. It permits use on websites and e-commerce shops subject to its restrictions; in particular, do not imply endorsement and do not use the photos as trademarks.

## Promo/banner photos

The carousel uses separate sample photography under `public/products/`; those images are not assigned to the catalogue. Original photo IDs and the Unsplash URL pattern remain documented below. Verify current Unsplash terms and model/property release requirements before production use.

| Local file | Unsplash photo ID |
| --- | --- |
| `black-tee.webp` | `photo-1583743814966-8936f5b7be1a` |
| `casual-shirt.webp` | `photo-1598033129183-c4f50c736f10` |
| `clothing-rack.webp` | `photo-1523381210434-271e8be1f52b` |
| `fashion-wear-1.webp` | `photo-1529139574466-a303027c1d8b` |
| `fashion-wear-2.webp` | `photo-1539109136881-3be0616acf4b` |
| `fashion-wear-3.webp` | `photo-1515886657613-9f3515b0c78f` |
| `leather-shoe.webp` | `photo-1495555961986-6d4c1ecb7be3` |
| `mens-tee.webp` | `photo-1521572163474-6864f9cf17ab` |
| `shoe-detail.webp` | `photo-1460353581641-37baddab0fa2` |
| `sneaker-blue.webp` | `photo-1525966222134-fcfa99b8ae77` |
| `sneaker-white.webp` | `photo-1515955656352-a1fa3ffcd111` |
| `women-dress.webp` | `photo-1512436991641-6745cdb1723f` |
| `women-flats.webp` | `photo-1515347619252-60a4bf4fff4f` |
| `women-heels.webp` | `photo-1543163521-1bf539c55dd2` |

Source pattern: `https://images.unsplash.com/<photo-id>?auto=format&fit=crop&w=720&h=760&q=78&fm=webp`.
